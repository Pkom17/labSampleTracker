# Spring Boot Rest api - telosys template

Telosys template to generate the spring boot rest api architecture.
